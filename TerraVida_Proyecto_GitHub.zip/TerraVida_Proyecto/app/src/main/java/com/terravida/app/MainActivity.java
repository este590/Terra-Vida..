package com.terravida.app;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.graphics.Color;
public class MainActivity extends Activity {
 private WebView webView;
 @Override public void onCreate(Bundle state) {
  super.onCreate(state);
  getWindow().setStatusBarColor(Color.rgb(18,31,49));
  getWindow().setNavigationBarColor(Color.rgb(18,31,49));
  webView=new WebView(this);
  webView.setBackgroundColor(Color.rgb(18,31,49));
  WebSettings s=webView.getSettings();
  s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true);
  s.setAllowFileAccess(true); s.setAllowContentAccess(true);
  webView.setWebViewClient(new WebViewClient());
  webView.setWebChromeClient(new WebChromeClient());
  setContentView(webView);
  webView.loadUrl("file:///android_asset/index.html");
 }
 @Override public void onBackPressed() {
  if(webView!=null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
 }
}
