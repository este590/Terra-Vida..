TERRAVIDA - PROYECTO PARA GENERAR APK EN GITHUB

1. Extrae este ZIP en ZArchiver.
2. Abre la carpeta TerraVida_Proyecto.
3. Sube TODO lo que está dentro al directorio principal de tu repositorio.
   Incluye la carpeta oculta .github. No subas solo el ZIP.
4. Confirma los cambios (Commit changes).
5. Abre Actions y ejecuta “Construir APK TerraVida”.
6. Cuando termine en verde, abre la ejecución y descarga “TerraVida-APK”.
7. Extrae el artefacto descargado: dentro estará app-debug.apk.

ESTRUCTURA EN LA RAÍZ:
.github/workflows/build-apk.yml
app/
build.gradle
gradle.properties
settings.gradle

Si existe un workflow anterior main.yml, elimínalo o desactívalo para evitar
que dos flujos compitan.

La APK debug sirve para pruebas e instalación manual, no para publicar
directamente en Play Store. Los puntos y retos se guardan localmente.
No hay cuentas en línea ni modo multijugador implementados todavía.
La guía de reciclaje es general; consulta las reglas de tu municipio.

Configuración: Java 17, Android Gradle Plugin 8.7.3, Gradle 8.9, SDK 35.
ID: com.terravida.app
